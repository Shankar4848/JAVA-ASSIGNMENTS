public class Book extends Author{

	String name;
	Double price;
	int qty=0;

	public Book (String name,String aname,String mail,char n, double price){
		super(aname,mail,n);
		this.name=name;
		this.price=price;
	}
	public Book (String name,String author,String mail,char n, double price, int qty){
		super(author,mail,n);
		this.name=name;
		this.price=price;
		this.qty=qty;
	}

	public String getname(){
		return this.name;
	}

	public String getauthor(){
		return super.name;
	}

	public Double getprice(){
		return this.price;
	}

	public void setprice(double d){
		this.price=d;
	}

	public int getqty(){
		return this.qty;
	}

	public void setqty(int qty){
		this.qty=qty;
	}
	public String toString(){
		return "\nBookname ="+name +super.toString()+"\nprice="+price +"\nquantity=" + qty;
	}

}