public class Testbook{

	public static void main(String[] args) {

		Book b1=new Book("java","SHASHI","SHASHI@5657",'M',500.00);
		Book b2=new Book("Rtos","RAJA","RAJA@123",'M',600.00,30);

		
		

		System.out.println("book name :"+b1.getname());
		System.out.println("Author :"+ b1.getauthor());
		System.out.println("Price ="+b1.getprice());
		System.out.println("Quantity ="+b1.getqty());

		b1.setprice(550.00);
		b1.setqty(10);
			System.out.println("**************");
		System.out.println(b1);
			System.out.println("**************");
		System.out.println(b2);
	}
}