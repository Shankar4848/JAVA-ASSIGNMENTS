public class Author{
	String name;
	String mail;
	char gender;

	Author(String name,String mail,char gender){
		this.name=name;
		this.mail=mail;
		this.gender=gender;
	}
	public String toString(){

		return "\nAuthor name ="+name +"\nmail ="+mail + "\ngender ="+gender;

	}
}