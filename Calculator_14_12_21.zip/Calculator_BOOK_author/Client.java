class Client {
    private static void testAdd() {
        Calculator calc = BasicCalculator.getInstance();
        assert(calc.put(101)
                   .put(-1)
                   .add()
                   .read() == 100);

        
    }

    private static void testDiv() {
        Calculator calc = BasicCalculator.getInstance();
        assert(calc.put(4)
                .put(2)
                .div()
                .read()==2);
       
    }
    private static void testsub(){
        Calculator calc= BasicCalculator.getInstance();
        assert(calc.put(5)
                .put(5)
                .sub()
                .read()==0);
    }
    private static void testmul(){
        Calculator calc= BasicCalculator.getInstance();
        assert(calc.put(5)
                .put(4)
                .mul()
                .read()==20);
    }

 

    public static void main(String args[]) {
        testAdd();
        testDiv();
        testsub();
        testmul();
       
    }
}
