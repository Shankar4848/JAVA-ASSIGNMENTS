import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.Button;
import java.awt.GridLayout;

public class LoginForm extends Frame{

	//Declare for the GUI component type.

	private Label lbl_user, lbl_password;
	private TextField txt_user, txt_password;
	private Button but_submit, but_reset;

	LoginForm(String title){
		super(title);
		//setTitle(title);

		setLayout(new GridLayout(3,2));

		//Call the appropriate constructor with the suitable arguments
		lbl_user = new Label("User Name");
		lbl_password = new Label("Password");

		txt_user = new TextField(20);
		txt_password = new TextField(20);		

		but_submit = new Button("Submit");
		but_reset = new Button("Reset");

		//Add these components to the container (Applet, Frame or Panel).
		add(lbl_user);
		add(txt_user);
		add(lbl_password);
		add(txt_password);
		add(but_submit);
		add(but_reset);

		setSize(400, 400);
		setVisible(true);
	}

	public static void main(String[] args) {
		
		new LoginForm("Login Form Window....");
	}

}


