
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import javax.swing.JOptionPane;

public class LoginFormSwing extends JFrame implements ActionListener{

	//Declare for the GUI component type.

	private JLabel lbl_user, lbl_password;
	private JTextField txt_user, txt_password;
	private JButton but_submit, but_reset;
	private Container contentPane;

	LoginFormSwing(String title){
		super(title);
		//setTitle(title);

		
		contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(3,2, 50, 50));

		//Call the appropriate constructor with the suitable arguments
		lbl_user = new JLabel("User Name");
		lbl_password = new JLabel("Password");

		txt_user = new JTextField(20);
		txt_password = new JTextField(20);		

		but_submit = new JButton("Submit");
		but_submit.addActionListener(this);
		but_reset = new JButton("Reset");
		but_reset.addActionListener(this);

		//Add these components to the container (Applet, Frame or Panel).
		contentPane.add(lbl_user);
		contentPane.add(txt_user);
		contentPane.add(lbl_password);
		contentPane.add(txt_password);
		contentPane.add(but_submit);
		contentPane.add(but_reset);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setSize(400, 400);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e){

		//System.out.println("received action object...");

		if(e.getSource()==but_submit){
			System.out.println("received action object. submit..");

			try{
				String username = txt_user.getText();
				String password= txt_password.getText();
				BufferedReader br= new BufferedReader(new FileReader("userdb.txt"));
				if(br!=null){
					String msg=br.readLine();
					String[] userdb = msg.split(" ");
					boolean flag=false;

					while(msg!=null){
						if((username.equals(userdb[0]))&&(password.equals(userdb[1]))){
							flag=true;
							break;
						}
						msg =br.readLine();
						if(msg!=null)
							userdb = msg.split(" ");
					}
					if(flag){
						System.out.println("valid user");
					}
					else{
						JOptionPane.showMessageDialog(this,"Invalid");
						txt_user.setText("");
			 			txt_password.setText("");
						System.out.println("invalid user");
					}
				}
				br.close();
			}catch(Exception ex){
				System.out.println(ex);

			}

		}
		else if(e.getSource()==but_reset){
			 txt_user.setText("");
			 txt_password.setText("");
			System.out.println("received action object. reset..");

		}

	}

	public static void main(String[] args) {
		
		new LoginFormSwing("Login Form Window....");
	}

}

