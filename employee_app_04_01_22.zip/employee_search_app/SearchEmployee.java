import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JList;
import javax.swing.JScrollPane;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.BorderLayout;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class SearchEmployee extends JFrame implements ActionListener
{
	private JLabel lbl_id, lbl_ename, lbl_age, lbl_address;
	private JTextField txt_id, txt_ename, txt_age, txt_address;
	private JButton but_search;
	private JPanel panel_search, panel_result;
	private JList list_employee;
	private JScrollPane scr_employee;

	private DBase db; 

	private Container contepane;

	SearchEmployee(String title)
	{
		super(title);
		contepane = getContentPane();

		/*********** Search Panel**********/	
		panel_search = new JPanel();

		lbl_id = new JLabel("Employee ID", JLabel.RIGHT);
		txt_id = new JTextField(20);
		but_search = new JButton("Search...");
		but_search.addActionListener(this);
		panel_search.add(lbl_id);
		panel_search.add(txt_id);
		panel_search.add(but_search);

		contepane.add(panel_search, BorderLayout.NORTH);
		/************* List Panel ************/

		/*scr_employee =  new JScrollPane(new JList());
		contepane.add(scr_employee, BorderLayout.WEST);*/

		/*********** Result Panel**********/	
		panel_result = new JPanel();
		panel_result.setLayout(new GridLayout(3,2));
	
		lbl_ename = new JLabel("Employee Name", JLabel.RIGHT);
		lbl_age = new JLabel("Age", JLabel.RIGHT);
		lbl_address = new JLabel("Address", JLabel.RIGHT);
		txt_ename = new JTextField(20);
		txt_age = new JTextField(20);
		txt_address = new JTextField(20);

		panel_result.add(lbl_ename);
		panel_result.add(txt_ename);
		panel_result.add(lbl_age);
		panel_result.add(txt_age);
		panel_result.add(lbl_address);
		panel_result.add(txt_address);

		preparedemo();
			
		contepane.add(panel_result, BorderLayout.CENTER);		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 300);
		setVisible(true);
	}

	public void preparedemo(){

		try{
			String drivername = "com.mysql.jdbc.Driver";
			String databasename = "jdbc:mysql://localhost:3306/testdb";
			db = new DBase();

			if(db.loadDriver(drivername)==1){

			}
			if(db.createConnection(databasename)==1){

			}

			String sql = "select * from employee where empid=?";

			if(db.getPrepareStatement(sql)==1){

			}
		}catch(Exception e){
				System.out.println(e);
			}
	}


	public void serarhemployeeDetails()
	{
		try{
			int id = Integer.parseInt(txt_id.getText().toString());

			db.searchRecord(id);

			if(db.rs!=null){
				db.rs.first();
				txt_ename.setText(db.rs.getString(1));
				txt_age.setText(String.valueOf(db.rs.getInt(3)));
				txt_address.setText(db.rs.getString(4));
			}
		}catch(Exception e){
			JOptionPane.showMessageDialog(this,"No record found..");
			txt_id.setText("");
			txt_ename.setText("");
			txt_age.setText("");
			txt_address.setText("");
		}

	
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == but_search)
		{
			serarhemployeeDetails();
		}
	}

	public static void main(String args[])
	{
		new SearchEmployee("Search Employee Details");
	}
}

