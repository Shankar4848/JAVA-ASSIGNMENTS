

public class Convert{
	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		System.out.println("enter the Temperature");
			double fahrenheit= sc.nextInt();  
		double celsius;
	
		celsius=(fahrenheit-32)/1.8;

		System.out.println("Temperature in celsius is "+celsius);

	}
}