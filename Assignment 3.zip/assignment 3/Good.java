import java.util.Scanner;

public class Good{
public static void main(String[] args) {

System.out.println("Display Question ");
System.out.println("MSIS stands for?");

Scanner sc = new Scanner(System.in);

System.out.println("Enter the Answer\n");

int count=0;

for(int i=0; i<3; i++) {        
	String answer = sc.next();
	
	if(answer.equalsIgnoreCase("Manipal school of information science")){
	System.out.println("Good"); 
	break;
}

else {
	System.out.println(" *****Wrong answer try once again*****");
count ++;
}
}
if(count == 3)
{
System.out.println("Better Luck next time ");
System.out.println("MSIS stands for Manipal school of information science "); 

}
}

