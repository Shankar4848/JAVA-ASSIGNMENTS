import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.Container;
import java.awt.GridLayout;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;



public class ViewRecord extends JFrame implements ActionListener
{
	private JLabel lbl_fname, lbl_lname, lbl_age, lbl_address;
	private JTextField txt_fname, txt_lname, txt_age, txt_address;
	private JButton but_prev, but_next;

	private DBase db; 

	private Container contepane;

	ViewRecord(String title)
	{
		super(title);
		contepane = getContentPane();
		contepane.setLayout(new GridLayout(5,2));

		lbl_fname = new JLabel("First Name", JLabel.RIGHT);
		lbl_lname = new JLabel("Last Name", JLabel.RIGHT);
		lbl_age = new JLabel("Age", JLabel.RIGHT);
		lbl_address = new JLabel("Address", JLabel.RIGHT);

		txt_fname = new JTextField();
		txt_lname = new JTextField();
		txt_age = new JTextField();
		txt_address = new JTextField();

		but_prev = new JButton("Pevious");
		but_prev.addActionListener(this);
		but_next = new JButton("Next");
		but_next.addActionListener(this);

		contepane.add(lbl_fname);
		contepane.add(txt_fname);
		contepane.add(lbl_lname);
		contepane.add(txt_lname);
		contepane.add(lbl_age);
		contepane.add(txt_age);
		contepane.add(lbl_address);
		contepane.add(txt_address);
		contepane.add(but_prev);
		contepane.add(but_next);
		try
		{
			displayRecord();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400, 400);
		setVisible(true);
	}

	public void displayRecord() throws Exception
	{
		//we need to connect to database and write the logic here. We need to create table and populate it.
		//If null we need to display as no records found.

		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/testdb";
			db = new DBase();
			if(db.loadDriver(drivername)==1){
				System.out.println("Driver created successfully");
			}
			if(db.createConnection(databasename)==1){
				System.out.println("Connection Established");
			}
			if(db.getStatement()==1){

			}
			String sql="select * from employee";
			db.retrieveRecord(sql);

			if(db.rs!=null)
			{
				//rs can be accessed anywhere check the reason sir explained.
				db.rs.first();
				txt_fname.setText(db.rs.getString(1));
				txt_lname.setText(db.rs.getString(2));
				txt_age.setText(String.valueOf(db.rs.getInt(3)));
				txt_address.setText(db.rs.getString(4));
			}
			else{
				JOptionPane.showMessageDialog(this,"No records found!!!!");
			}


	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == but_prev)
		{
			try{
				if(db.rs.isFirst()){
					JOptionPane.showMessageDialog(this,"First Record!!!!");
				}
				else{
						db.rs.previous();
						txt_fname.setText(db.rs.getString(1));
						txt_lname.setText(db.rs.getString(2));
						txt_age.setText(String.valueOf(db.rs.getInt(3)));
						txt_address.setText(db.rs.getString(4));
				}
				
			}
			catch(Exception ex){

			}
			
		}

		else if (e.getSource() == but_next)
		{
			try{
				if(db.rs.isLast()){
					JOptionPane.showMessageDialog(this,"Last Record!!!!");
				}
				else{
						db.rs.next();
						txt_fname.setText(db.rs.getString(1));
						txt_lname.setText(db.rs.getString(2));
						txt_age.setText(String.valueOf(db.rs.getInt(3)));
						txt_address.setText(db.rs.getString(4));
				}
				
			}
			catch(Exception ex){

			}
			
		}

	}

	public static void main(String args[])
	{
		new ViewRecord("Employee details");
	}
}









