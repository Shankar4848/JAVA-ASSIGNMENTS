import java.util.Scanner;

public class EIS{
	public static void main(String[] args){
		int id,i,SIZE,id2,j=0,id3;
		String name,desig;
		String option;
		String y,n;
		double sal;
		y = "y";
		n = "n";


		Scanner sc = new Scanner(System.in);
		System.out.println("How many employee details you want to add to the database \n");
		SIZE = sc.nextInt();

		Employee e[] = new Employee[SIZE]; 
		for (i=0;i<SIZE;i++)
		{
			System.out.println("Enter the id of "+ (i+1) +" employee");
			id = sc.nextInt();
			System.out.println("Enter the name of "+ (i+1) +" employee");
			name = sc.next();
			System.out.println("Enter the designation of "+ (i+1) +" employee");
			desig = sc.next();
			System.out.println("Enter the salary of "+(i+1)+" employee");
			sal = sc.nextDouble();
			Employee e[i] = new Employee(id,name,desig,sal);
		}


	System.out.println("Type y if want to search any employee details?");
	option = sc.next();
	if(option.equalsIgnoreCase(y))
	{	
	do
	{
		System.out.println("Enter the id of the employee you want to search \n");
		id2 = sc.nextInt();
			for (i=0;i<SIZE;i++)
			{
				if (e[i].SearchDetails(id2))
				{
				e[i].DisplayEmployeeDetails();
				break;
				}
			j = j+1;
			}
			if (j == SIZE)
			{
				System.out.println("The employee details not found for the specified ID please enter a valid employee ID\n");
			}
			j=0;

		 	System.out.println("Press Y if you want to continue searching employee details or press N to exit \n");
		 	option = sc.next();
	}while(option.equalsIgnoreCase(y));
}
	if (option.equalsIgnoreCase(n))
	{
		System.out.println("You have exited the search\n");
	}
	System.out.println("Enter Y if you want to increment the salary of any employee or enter N to exit the program\n");
	option = sc.next();
	while(option.equalsIgnoreCase(y)){
	if (option.equalsIgnoreCase(y))
	{
	System.out.println("Enter the id of the employee whose salary needs to be incremented \n");
	id3 = sc.nextInt();
	for (i=0;i<SIZE;i++)
	{
		if (e[i].SearchDetails(id3))
			{
			e[i].SalaryIncrement(id3);
			}
		}	
	}
	System.out.println("Enter Y if you want to continue to increment the salary of any other employee or enter N to exit the program\n");
	option = sc.next();
}
	if (option.equalsIgnoreCase(n))
	{
		System.out.println("You have exited the program.");
	}
	else
	{
		System.out.println("Please enter a valid option");
	}
}	
}