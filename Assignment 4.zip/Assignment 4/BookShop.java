import java.lang.String;
import java.util.Scanner;



public class BookShop{
	public static void main(String[] args){
		int i,SIZE,j=0;
		String title,author,publisher;
		int stock,option,check,price;
		Scanner sc = new Scanner(System.in);
		System.out.println("How many books you want to add to the database \n");
		SIZE = sc.nextInt();
		Book b[] = new Book[SIZE]; 
		for (i=0;i<SIZE;i++)
		{
			System.out.println("Enter the title of the "+ (i+1) +" book");
			title = sc.next();
			System.out.println("Enter the author of the book "+title);
			author = sc.next();
			System.out.println("Enter the publisher of the book "+title+" written by "+author);
			publisher = sc.next();
			System.out.println("Enter the price of the book "+title+" written by "+author);
			price = sc.nextInt();
			System.out.println("Enter the number of available copies of the book "+title+" written by "+author);
			stock = sc.nextInt();
			b[i] = new Book(author,title,publisher,price,stock);
		}

	do
	{
		System.out.println("Enter the title of the book you want to search \n");
		title = sc.next();
		System.out.println("Enter the author of that book \n");
		author = sc.next();
			for (i=0;i<SIZE;i++)
			{
				if (b[i].SearchDetails(title,author))
				{
				b[i].DisplayBookDetails();
				System.out.println("The details of the requested book have been displayed");
				b[i].StockSearch(title,author);

				break;
				}
			j = j+1;
			}
			if (j == SIZE)
			{
				System.out.println("The book details not found in the Database. \n");
			}

			j=0;
		 	System.out.println("Press 1 if you want to continue searching for Book details or press 2 to exit \n");
		 	option = sc.nextInt();
	}while(option == 1);
	if (option == 2)
	{
		System.out.println("You have exited the search");
	}
	
	}
}