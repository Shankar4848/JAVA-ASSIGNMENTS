public class Book_store{
	
	private String author;
	private String title;
	private String publisher;
	private int price;
	private int stock;
	

	Book(String book_author, String book_title , String book_publisher ,int book_cost, int stock_position){
		author = book_author ;
		title = book_title ;
		publisher = book_publisher;
		price = book_cost ; 
		stock = stock_position;
	}

	public void DisplayBookDetails(){

		System.out.println("Book details are ");
		System.out.println("Book title :-"+ title);
		System.out.println("Author name :- "+ author);
		System.out.println("Book Publisher:- "+ publisher);
		System.out.println("The cost of the Book is :- "+ price+"\n");
	}

	public boolean SearchDetails(String title1,String author1){

		if ((title1.equalsIgnoreCase(title)) && (author1.equalsIgnoreCase(author)) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public void StockSearch(String title2,String author2)
	{
	System.out.println("Enter the number of copies you want to purchase.");
	int n = newbook.nextInt();
	int total_cost;
		if(n<=stock)
		{
		System.out.println("There are "+stock+" copies of the book available in the stock.");
		total_cost = n*(price);
		System.out.println("Pay Rs. "+total_cost+" in total to purchase the requested number of copies\n");
		}
		else
		System.out.println("Requested number of copies are not available in the stock.There are only "+stock+" copies available");
}
}
