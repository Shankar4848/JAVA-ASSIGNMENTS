import java.util.Scanner;

public class Employee{

	private int emp_id;
	private String emp_name;
	private String designation;
	private double emp_salary;



	Employee(int id,String name,String desig,double salary){
		emp_id = id;
		emp_name = name;
		designation = desig;
		emp_salary = salary; 
	}



	public void DisplayEmployeeDetails(){
		System.out.println("Employee details are ");
		System.out.println("id:- "+ emp_id);
		System.out.println("name:- "+ emp_name);
		System.out.println("designation:- "+ designation);
		System.out.println("salary:- "+ emp_salary);

	}

	public boolean SearchDetails(int id1){
		if (id1 == emp_id)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

public void SalaryIncrement(int id){
		double prev_sal;
		prev_sal = emp_salary;
		emp_salary = (emp_salary)+(emp_salary)*(0.1);
		System.out.println("The salary of the employee with employee id "+id+" has been incremented by 10%");
		System.out.println("The previous salary of the employee was Rs."+prev_sal+" and current salary of the employee is Rs."+emp_salary+"\n");
}
}