

public class Cel{
	public static void main(String[] args) {
		
		double fahrenheit,celsius;
		fahrenheit=100;
		celsius=(fahrenheit-32)/1.8;

		System.out.println("Temperature in celsius is "+celsius);

	}
}