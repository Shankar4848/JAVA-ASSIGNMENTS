/*Given a number, write a program using while loop reverse the digits of the number For example, the number 12345 should be written as 
54321 (Hint: Use modulus operator to extract the last digit and the integer division by 10 to get the n-1 digit number from the n digit
 number)*/ 

public class Reverse{  
	public static void main(String[] args)   
	{  
		int number = 12345, reverse = 0,remainder;  
		while(number != 0)   
			{  
			    remainder = number % 10;  
				reverse = reverse * 10 + remainder;  
				number = number/10;  
			}

System.out.println("The reverse of the given number is: " + reverse);  
}  
}  