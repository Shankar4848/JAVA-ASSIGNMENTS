//Allow the user to enter 10 numbers. Find max, min and sort the input.

import java.util.Scanner;
import java.util.Arrays;
public class Maximum{
	public static void main(String[] args) {

		int count,max,min,i,j,temp=0;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the array");
		count=sc.nextInt();
        int a[]=new int[count];

		
		System.out.println("Enter" +count+ "nos"); // array input

		for(i=0;i<count;i++){
			a[i]=sc.nextInt();	
		}

    min=max=a[0];
    for(i=1; i<count; i++)
    {
         if(min>a[i])
		  min=a[i];   
		   if(max<a[i])
		    max=a[i];
	}

	System.out.println("Largest no " +max);
    System.out.println("Smallest no " +min);

    Arrays.sort(a);
    System.out.println("Sorted arrays are: ");

	for(i=0; i<a.length; i++){
		/*for(j=0;j<count;j++){// if needed bubble sort
		if(a[j]>a[j+1]){
			temp=a[j];
			a[j]=a[j+1];
			a[j+1]=temp;
		}
	}*/
	System.out.println(+a[i]);
}
}
}




		

  