//Floyd's Triangle

import java.util.Scanner;
public class FloydTriangle{
public static void main(String[] args) {

System.out.println(" Floyd's Triangle ");
Scanner sc = new Scanner(System.in);
System.out.println("Enter the no of rows");
int n = sc.nextInt();

int count=1; //starting to print 1

for(int i=0; i<n; i++){
for( int j=0; j<=i; j++) //print until i th number
{
	System.out.print(count +"\t");
	count++;
}
System.out.println();
}

// Floyd's Triangle to print 0's and 1's
System.out.println();
for(int i=0;i<n; i++){

	for( int j=0; j<=i; j++){

	if((i%2)==(j%2)) // for printing 1, the values of i and j must be even or odd, but not opposite
	System.out.print("1 ");
	else
		System.out.print("0 ");
}
    System.out.println();
}
}
}
