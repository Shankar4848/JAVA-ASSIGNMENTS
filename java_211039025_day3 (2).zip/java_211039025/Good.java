/*Display a question to user allow the user to answer the question. Allow 3 chances to user. If correct answer display
 "Good" else display correct answer after 3 attempts.*/

import java.util.Scanner;

public class Good{
public static void main(String[] args) {

System.out.println("Display Question ");
System.out.println("Where is Manipal located in Karnataka?");

Scanner sc = new Scanner(System.in);

System.out.println("Enter the Answer\n");

int count=0;

for(int i=0; i<3; i++) {        //asking to enter the answer 3 times
	String answer = sc.next();
	
	if(answer.equalsIgnoreCase("Udupi")){
	System.out.println("Good"); //print good if answer is right
	break;
}

else {
	System.out.println(" Wrong answer try once again");
count ++;
}
}
if(count == 3)
{
System.out.println("Better Luck next time ");
System.out.println("The right answer is Udupi"); //print right answer if 3 attempts are done
}

}
}

