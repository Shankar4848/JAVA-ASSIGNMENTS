public class Hwitem extends Sales {

	private String category;
	private String owner;


	 Hwitem(){
	 	super();
	 	category = null;
	 	owner= null;
	 }
	 Hwitem(String title,double prize, double[] sales, String category, String owner)
	 {
	 	super(title,prize,sales);
	 	this.category=category;
	 	this.owner=owner;
	 }

	 public String getcategory(){
	 	return this.category;
	 }
	 public String getowner(){
	 	return this.owner;
	 }

	 public void setcategory(String category){
	 	this.category=category;
	 }
	  public void setowner(String owner){
	 	this.owner=owner;
	 }


	 @Override
	 public String toString(){
		return " HARDWARE category= " + category + " \n original equipment manufacturer :" + owner + super.toString();
	}
}