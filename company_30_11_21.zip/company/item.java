public class item{

	private String title;
	private double prize;

	item(){
		title="";
		prize=0.0;
	}
	item(String title,double prize){
		this.title=title;
		this.prize=prize;
	}

	public String gettitle(){
		return this.title;
	}
	public void settitle(String title){
		this.title=title;

	}
	public double getprize(){
		return this.prize;
	}
	/*public void setprize(double prize){
		this.prize= prize;
	}*/
	public String toString(){
		return"\n item title = "+ this.title+"\n prize = "+this.prize;
	}
}