import java.util.Scanner;


public class Testcompany{

	public static void main(String[] args) {

		Switem[] sw=null;
		Hwitem[] hw=null;

		/*double[] data={34.00,45.00,50.00};
		
		Switem obj1 = new Switem("Greenhouse", 22.22,data,"recruiting tool","windows");
		System.out.println(obj1);*/

	Scanner sc=new Scanner(System.in);
	double[] data = new double[3];

	

	int flag=1, size=0,a=0;

while(flag==1){
	System.out.println("enter 1 to enter the hardware item detailes // 0 to enter software item detailes");
	int count= sc.nextInt();

	if(count==1)
	{
		System.out.println("enter the number of items: ");
		 size =  sc.nextInt();

		 hw = new Hwitem[size];

		for(int i=0; i<size;i++){

			System.out.println("enter item name");
			String name= sc.next();
			System.out.println("enter prize: ");
			double prize= sc.nextDouble();
			System.out.println("enter net sales of 3 months: ");
			for(int j=0;j<3;j++){
			 	data[j] = sc.nextDouble();
			}
			System.out.println("enter item category");
			String category= sc.next();
			System.out.println("enter item manufacturer");
			String owner= sc.next();
			hw[i]= new Hwitem(name,prize,data,category,owner);
		}
	}
	else if (count==0)
	{
		System.out.println("enter the number of items: ");
		 a =  sc.nextInt();

		 sw =new  Switem[a];

			for(int i=0; i<a;i++)
			{
			System.out.println("enter item name");
			String name= sc.next();
			System.out.println("enter prize: ");
			double prize= sc.nextDouble();
			System.out.println("enter net sales of 3 months: ");
			for(int j=0;j<3;j++){
				 data[j] = sc.nextDouble();
			}
			System.out.println("enter software type: ");
			String software= sc.next();
			System.out.println("enter OS type");
			String os= sc.next();

			sw[i]= new Switem(name,prize,data,software,os);
		}
	}
	else
		break;

	System.out.println("enter 1 to continue entering detailes 0 display all the detailes");
	flag=sc.nextInt();
}

for(int i=0; i<size; i++){
	System.out.println(hw[i]);
}

for(int i=0; i<a;i++){
	System.out.println(sw[i]);
}

}
}