public class Switem extends Sales{

	 private String software;
	 private String os;


	 Switem(){
	 	super();
	 	software = null;
	 	os= null;
	 }
	 Switem(String title,double prize, double[] sales, String software, String os)
	 {
	 	super(title,prize,sales);
	 	this.software=software;
	 	this.os=os;
	 }

	 public String getsoftware(){
	 	return this.software;
	 }
	 public String getos(){
	 	return this.os;
	 }

	 public void setsoftware(String software){
	 	this.software=software;
	 }
	  public void setos(String os){
	 	this.os=os;
	 }


	 @Override
	 public String toString(){
		return  super.toString() + " \nSOFTWARE type = " + software + "\n OS type:" + os;
	}
}
