public class Sales extends item{

	private double sales[];

	Sales(){
		super();
		sales= null;
	}
	Sales(String title,double prize, double[] sales){
		super(title,prize);
		this.sales=sales;
	}

	public double[] getsales(){
		return this.sales;
	} 
	public void setsales(double[] sales){
		this.sales=sales;
	}

	public String toString(){
		return  super.toString()+ "\n net sales: 1st month: " + sales[0] +" \n 2nd month :"+ sales[1] + "\n 3rd month sale : "+ sales[2];
	
}
}