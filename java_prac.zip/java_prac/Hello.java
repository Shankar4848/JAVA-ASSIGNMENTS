//Write a Simple "Hello World" program in java. Understand the build process and also the runtime settings needed to run java programs.

public class Hello{
	public static void main(String[] args) {
		
		System.out.println("HelloWorld!!!");
	}
}
