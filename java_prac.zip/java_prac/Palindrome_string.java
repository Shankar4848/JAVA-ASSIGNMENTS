//Check whether entered string is a palindrome or not

import java.util.Scanner;
public class Palindrome_string{
	public static void main(String[] args) {
		
		String x,y="";
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the string ");
		x=sc.next();
		int l=x.length();

		for(int k=l-1;k>=0;k--)
		{
			y= y+ x.charAt(k);
		}

       if(x.equals(y)){
       
       	System.out.println(" palindrome ");
       }
       
       	else
       	{
       	
       		System.out.println("not palindrome ");
       	}
       }
	
}