//Write a program that prints the sum of 3 numeric arguments taken from command line.

public class Three_arguments{
	public static void main(String[] args){
		int a= Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
		int c= Integer.parseInt(args[2]);

		int sum=a+b+c;

		System.out.println("The sum of "+ args[0] + "and" + args[1] + "and" + args[2] +"is: " +sum );
	}
}