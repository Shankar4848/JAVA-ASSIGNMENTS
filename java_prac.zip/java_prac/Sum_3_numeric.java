//Write a program that prints 3 arguments taken from command line.

public class Sum_3_numeric{
	public static void main(String[] args) {
		System.out.println("The 3 parameters are: ");
		
		for(int i=0;i<3;i++)
			System.out.println(args[i]);
	}
}