// Allow the user to enter a string and display the string in alphabetic order and find the length of string.

import java.util.Arrays;
import java.util.Scanner;

public class Alpha {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a string : ");
        String userInput = scanner.nextLine();

        char[] charArray = userInput.toCharArray();

        Arrays.sort(charArray);
        System.out.println("Sorted string " + String.valueOf(charArray));
        int str_length = userInput.length();
	    System.out.print("length of string is: " +str_length);
    }
}