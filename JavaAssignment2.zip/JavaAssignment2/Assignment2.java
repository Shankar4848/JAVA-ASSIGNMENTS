
//Write a Java program to find the duplicate values of an array of integer values

public class Assignment2
{
	public static void main(String[] args)
	{
		int[] array_input = {1,2,2,3,4,5,5,6,7,8,8,9,10,10,11,11,12,12};

		System.out.println("Duplicate Element in the given array is :");

		for(int i=0;i<array_input.length;i++)
		{
			for(int j=i+1;j<array_input.length;j++)
			{
				if(array_input[i] == array_input[j])
				{
					 System.out.println(array_input[j]);
				}
			}
		}

	}
}