
//Write a Java program to find the numbers greater than the average of the numbers of a given array.

import java.util.Scanner;
public class Assignment4
{
	public static void main(String[] args)
	{
		int[] array_input = {2, 3, 5, 4, 6, 9, 10 }; 
		int n=7;
        float average = 0;

        System.out.println("Number greater than the average of the given array is :");
 
        for (int i = 0; i < n; i++)
        
            average += array_input[i];
        	average = average / n;

        for (int i = 0; i < n; i++)
            if (array_input[i] > average)
                System.out.println(array_input[i] + " ");
    
	}
}