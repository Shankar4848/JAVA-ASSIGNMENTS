
//Write a Java program to convert minutes into a number of years and days

import java.util.Scanner;
public class Assignment1 
{

    public static void main(String[] args)
     {
		double minutesintoyears = 24 * 60 *365;

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the time in minutes: ");

        double minutes = sc.nextDouble();

        long years = (long) (minutes / minutesintoyears);
        int days = (int) (minutes / (60 * 24));
        
        System.out.println((int) minutes + " given minutes is approximately " + years + " years and " + days + " days");
    }
}